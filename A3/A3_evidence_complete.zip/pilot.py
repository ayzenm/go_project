import os, time, json, pathlib, random
os.environ['TF_NUM_INTRAOP_THREADS']='2'
os.environ['TF_NUM_INTEROP_THREADS']='2'
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np
random.seed(0); np.random.seed(0); tf.set_random_seed(0)
from tensorflow.keras.datasets import mnist
(x,y),(xt,yt)=mnist.load_data()
from lottery_ticket.foundations import save_restore
save_restore.save_network('/content/A3_compat/data/mnist',dict(x_train=x,y_train=y,x_test=xt,y_test=yt))
from lottery_ticket.mnist_fc import lottery_experiment
print('Devices',tf.config.list_physical_devices('GPU'),flush=True)
t=time.perf_counter()
lottery_experiment.train(output_dir='/content/A3_compat/pilot_output',mnist_location='/content/A3_compat/data/mnist',iterations=0,train_order_seed=0)
print('TRAINING_SECONDS',time.perf_counter()-t,flush=True)
